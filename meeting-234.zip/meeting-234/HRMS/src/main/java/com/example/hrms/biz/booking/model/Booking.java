package com.example.hrms.biz.booking.model;

import com.example.hrms.enumation.*;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Booking {
    private Long bookingId;
    private String username;
    private Long roomId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private BookingStatusEnum status;
    private String title; // Thêm trường title
    private String attendees; // Thêm trường attendees
    private BookingType bookingType; // Thêm trường bookingType
    private String weekdays; // Thêm trường weekdays cho Weekly
    private LocalDate startDate; // Thêm trường startDate cho Daily và Weekly
    private LocalDate endDate; // Thêm trường endDate cho Daily và Weekly
}