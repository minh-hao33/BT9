package com.example.hrms.biz.booking.model.dto;

import com.example.hrms.biz.booking.model.Booking;
import com.example.hrms.enumation.BookingType;
import com.example.hrms.enumation.BookingStatusEnum;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import com.example.hrms.utils.DateUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BookingDTO {

    @Getter
    @Setter
    public static class Req {
        private Long bookingId;
        private String username;
        private Long roomId;
        private String startTime;
        private String endTime;
        private String status;
        private String title; // Thêm trường title
        private String attendees; // Thêm trường attendees
        private String bookingType; // Thêm trường bookingType
        private String weekdays; // Thêm trường weekdays cho Weekly
        private String startDate; // Thêm trường startDate cho Daily và Weekly
        private String endDate; // Thêm trường endDate cho Daily và Weekly

        public static Req fromBooking(Booking booking) {
            Req req = new Req();
            BeanUtils.copyProperties(booking, req);
            DateTimeFormatter formatter = DateUtils.getDateTimeFormatter();
            req.setStartTime(booking.getStartTime().format(formatter));
            req.setEndTime(booking.getEndTime().format(formatter));
            req.setStatus(booking.getStatus().name());
            req.setBookingType(booking.getBookingType() != null ? booking.getBookingType().name() : null);
            req.setStartDate(booking.getStartDate() != null ? booking.getStartDate().toString() : null);
            req.setEndDate(booking.getEndDate() != null ? booking.getEndDate().toString() : null);
            req.setWeekdays(booking.getWeekdays());
            return req;
        }

        public Booking toBooking() {
            Booking booking = new Booking();
            BeanUtils.copyProperties(this, booking);
            DateTimeFormatter formatter = DateUtils.getDateTimeFormatter();
            booking.setStartTime(LocalDateTime.parse(this.startTime, formatter));
            booking.setEndTime(LocalDateTime.parse(this.endTime, formatter));
            booking.setStatus(BookingStatusEnum.valueOf(this.status));
            booking.setBookingType(BookingType.valueOf(this.bookingType));
            booking.setStartDate(this.startDate != null ? LocalDate.parse(this.startDate) : null);
            booking.setEndDate(this.endDate != null ? LocalDate.parse(this.endDate) : null);
            booking.setWeekdays(this.weekdays);
            return booking;
        }
    }

    @Getter
    @Setter
    public static class Resp {
        private Long bookingId;
        private String username;
        private Long roomId;
        private String startTime;
        private String endTime;
        private String status;
        private String title; // Thêm trường title
        private String attendees; // Thêm trường attendees
        private String bookingType; // Thêm trường bookingType
        private String weekdays; // Thêm trường weekdays cho Weekly
        private String startDate; // Thêm trường startDate cho Daily và Weekly
        private String endDate; // Thêm trường endDate cho Daily và Weekly

        public static Resp toResponse(Booking booking) {
            Resp resp = new Resp();
            BeanUtils.copyProperties(booking, resp);
            DateTimeFormatter formatter = DateUtils.getDateTimeFormatter();
            resp.setStartTime(booking.getStartTime().format(formatter));
            resp.setEndTime(booking.getEndTime().format(formatter));
            resp.setStatus(booking.getStatus().name());
            resp.setTitle(booking.getTitle());
            resp.setAttendees(booking.getAttendees());
            resp.setBookingType(booking.getBookingType() != null ? booking.getBookingType().name() : null);
            resp.setStartDate(booking.getStartDate() != null ? booking.getStartDate().toString() : null);
            resp.setEndDate(booking.getEndDate() != null ? booking.getEndDate().toString() : null);
            resp.setWeekdays(booking.getWeekdays());
            return resp;
        }
    }
}