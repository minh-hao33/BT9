package com.example.hrms.biz.booking.controller;

import com.example.hrms.biz.booking.model.Booking;
import com.example.hrms.biz.booking.model.dto.BookingDTO;
import com.example.hrms.biz.booking.service.BookingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/bookings")
public class BookingController {
    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @RequestMapping("")
    public String openBookingView(Model model) {
        model.addAttribute("booking", new BookingDTO.Req());
        return "bookings";
    }

    @GetMapping("/view")
    public String openViewRoom(Model model) {
        List<BookingDTO.Resp> bookings = bookingService.getAllBookings();
        if (bookings == null || bookings.isEmpty()) {
            model.addAttribute("error", "No bookings found");
        } else {
            model.addAttribute("bookings", bookings);
        }
        return "viewroom";
    }

    @GetMapping("/details/{bookingId}")
    @ResponseBody
    public BookingDTO.Resp getBookingDetails(@PathVariable Long bookingId) {
        Booking booking = bookingService.getBookingById(bookingId);
        return BookingDTO.Resp.toResponse(booking);
    }

    @GetMapping("/edit")
    public String openEditBookingView(@RequestParam("bookingId") Long bookingId, Model model) {
        Booking booking = bookingService.getBookingById(bookingId);
        model.addAttribute("booking", BookingDTO.Req.fromBooking(booking));
        return "bookingedit";
    }

    @PostMapping("/edit")
    public String editBooking(@ModelAttribute BookingDTO.Req bookingReq) {
        Booking booking = bookingReq.toBooking();
        bookingService.handleBookingType(booking);
        bookingService.updateBooking(booking);
        return "redirect:/bookings/view";
    }

    @GetMapping("/delete")
    public String openDeletePopup(@RequestParam("bookingId") Long bookingId, Model model) {
        model.addAttribute("bookingId", bookingId);
        return "popup";
    }

    @PostMapping("/delete")
    public String deleteBooking(@RequestParam("bookingId") Long bookingId) {
        bookingService.deleteBooking(bookingId);
        return "redirect:/bookings/view";
    }

    @PostMapping("/create")
    public String createBooking(@ModelAttribute BookingDTO.Req bookingReq, Model model) {
        Booking booking = bookingReq.toBooking();
        bookingService.handleBookingType(booking);
        bookingService.insert(bookingReq);
        return "redirect:/bookings/view";
    }
}